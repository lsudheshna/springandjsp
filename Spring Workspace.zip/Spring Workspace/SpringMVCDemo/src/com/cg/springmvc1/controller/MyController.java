package com.cg.springmvc1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MyController//user-defined controller 
{
	@RequestMapping(value="all",method=RequestMethod.GET)//url-mapping:all is forwarded from index.jsp 
	public String getAll()
	{
		return "home";
	}
}
